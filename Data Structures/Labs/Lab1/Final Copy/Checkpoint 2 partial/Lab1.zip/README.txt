LAB 1: GETTING STARTED


NAME:  Sameer Sawla



COLLABORATORS AND OTHER RESOURCES:

Talked To : Anand Sahu

Book : Let us C++ by Yeshwant Kanitkar

Citations :
http://www.cplusplus.com/doc/tutorial/arrays/

NAMES OF YOUR TA & MENTORS

Who is your graduate lab TA? 

Salles

Who are the undergraduate programming mentors assigned to your lab?

Jesse
Lars
Cameron
Jack












