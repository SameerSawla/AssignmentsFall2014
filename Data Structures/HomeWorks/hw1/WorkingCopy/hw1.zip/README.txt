HOMEWORK 1: MOIRE STRINGS

NAME:  Sameer Sawla

COLLABORATORS AND OTHER RESOURCES:
Anand Sahu
Anshul Kataria

StackOverFlow.com
CplusPlus.com

ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  6

MISC. COMMENTS TO GRADER:  
I took the class in the Spring 2013 also. I think this assignment is a lot easier then the first assignment in the last semester.


