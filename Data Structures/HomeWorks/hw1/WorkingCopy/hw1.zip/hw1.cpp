#include<iostream>
#include<string>
#include<sstream>
#include<fstream>
using namespace std;

//Calculates the text to be pushed in each line of the formed user selected polygon
string mid_dataF(int count, int &pointerLocation,string userEnteredString)
{
 
 string result;
 for(unsigned int i=0;i<count;i++)
 {
 	result = result + userEnteredString[pointerLocation];
 	pointerLocation++;
 	pointerLocation = pointerLocation%(userEnteredString.size());
 }
 return result;
}

//Processes Right Triangle Polygon
string ProcessRightTriangle(int heightOfPolygon,string userEnteredString)
{
			int pointerLocation = 0;
			string resultString = "";
			string start_one = "*";
			string start_two = "**";
			string end(heightOfPolygon,'*');
			resultString = resultString + start_one + "\n";
			resultString = resultString + start_two + "\n";
			for(unsigned int i=0;i<heightOfPolygon-3;i++)
			{	
				
				resultString = resultString + "*";
				resultString = resultString + mid_dataF(i+1,pointerLocation,userEnteredString);
				resultString = resultString + "*\n";
			}
			resultString = resultString + end + "\n";	
			return resultString;
}

//Processes Square Polygon
string ProcessSquare(int heightOfPolygon,string userEnteredString)
{
			int pointerLocation = 0;
			string resultString = "";
			int midDataHeight = heightOfPolygon-2;
			string start_end(heightOfPolygon,'*');
			string mid_data(midDataHeight,' ');
			resultString = resultString + start_end + "\n";
			for(unsigned int i=0;i<heightOfPolygon-2;i++)
			{	
				
				resultString = resultString + "*";
				resultString = resultString + mid_dataF(midDataHeight,pointerLocation,userEnteredString);
				resultString = resultString + "*\n";		
				
			}
			resultString = resultString + start_end + "\n";
			return resultString;

}

//Processes Isosceles Triangle Polygon
string ProcessIsoscelesSquare(int heightOfPolygon,string userEnteredString)
{
		int pointerLocation = 0;
		string resultString="";						
		for(unsigned int i=0;i<heightOfPolygon-1;i++)
			{	
				string spaced(heightOfPolygon-1-i,' ');
				resultString = resultString + spaced + "*";
				if(i!=0)	
				{
					resultString = resultString + mid_dataF(2*i-1,pointerLocation,userEnteredString);
					resultString = resultString + "*\n";
				}
				else
				{
					resultString = resultString + "\n";
				}
				
			}

		string endIt(2*heightOfPolygon-1,'*');
		resultString = resultString + endIt;
		return resultString;

}

//Prints to the file with the name given by the user.
void printToFile(string resultString,string nameOfTheFile)
{
 	ofstream myfile;
  	myfile.open (nameOfTheFile.c_str());
  	myfile << resultString;
  	myfile.close();
}

//Main function of the program
int main(int argc, char* argv[])
{
	//Initiating initial sets of test to check for valid inputs

	//Checking for proper number of inputs
	if(argc!=5)
	{
		std::cerr<<"ERROR : Please enter exact arguments\n";
		return 1;
	}


	int heightOfPolygon ;
	string shapeOfPolygon = argv[3];
	for(unsigned int i=0;i<shapeOfPolygon.size();i++)
	{
		shapeOfPolygon[i] = tolower(shapeOfPolygon[i]);
	}

	//Checking for proper input of the shape of polygon
	if(shapeOfPolygon.compare("isosceles_triangle")!=0 && shapeOfPolygon.compare("right_triangle")!=0 && shapeOfPolygon.compare("square")!=0)
	{
		cerr<< "ERROR : Enter correct expecte shape of Polygon. \n";
		return 1;
	}

	string userEnteredString = argv[1];

	//Checking for user entered string to be non-empty
	if(userEnteredString.compare("")==0)
	{
		cerr<<"ERROR : Please enter an un-empty String\n";
	}

	string nameOfTheFile = argv[4];
	string resultString;
	std::istringstream iss( argv[2] );
	iss >> heightOfPolygon;

	//Checking for whether the entered height is a number
	if(iss.eof()==false)
	{
		cerr<<"ERROR : Height entered should be a number.\n";
		return 1;
	}


	if(shapeOfPolygon=="right_triangle")
	{
		if(heightOfPolygon>3)
		{	
			
			resultString = ProcessRightTriangle(heightOfPolygon,userEnteredString);
		}	
		else
		{
			cerr<<"ERROR : Wrong height for the polygon "<<shapeOfPolygon<<"\n";
			return 1;
		}
	}

	if(shapeOfPolygon=="square")
	{
		if(heightOfPolygon>2)
		{	
			resultString = ProcessSquare(heightOfPolygon,userEnteredString);
		}	
		else
		{
			cerr<<"ERROR : Wrong height for the polygon "<<shapeOfPolygon<<"\n";
			return 1;
		}
	}


	if(shapeOfPolygon=="isosceles_triangle")
	{
		
		if(heightOfPolygon>1)
		{	
			resultString = ProcessIsoscelesSquare(heightOfPolygon,userEnteredString);
		}	
		else
		{
			cerr<<"ERROR : Wrong height for the polygon "<<shapeOfPolygon<<"\n";
			return 1;
		}
	}

	printToFile(resultString,nameOfTheFile);
	
	return 0;
}