HOMEWORK 1: MOIRE STRINGS

NAME:  Sameer Sawla

COLLABORATORS AND OTHER RESOURCES:
Anand Sahu
Anshul Kataria

StackOverFlow.com
CplusPlus.com

ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  6

MISC. COMMENTS TO GRADER:  
I took the class in the Spring 2013 also. I think this assignment is a lot easier then the first assignment in the last semester.

EXTRA CREDIT: 
I have tried to implement four other shapes apart from the given ones. 

1. Parallelogram
   Minimum Height : 3
   Sample Command to Run : ./a.out abcde 15 parallelogram a.txt
2. Trapezium
   Minimum Height : 3
   Sample Command to Run : ./a.out abcde 15 trapezium a.txt
3. X-Shape (see for * forming an X-shape between the text)
   Minimum Height : 3
   Sample Command to Run : ./a.out abcde 15 x_shape a.txt
4. House 
   Minimum Height : 3
   Sample Command to Run : ./a.out abcde 15 house a.txt

